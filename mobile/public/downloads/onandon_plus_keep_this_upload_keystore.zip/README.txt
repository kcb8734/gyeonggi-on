온앤온+ 업로드 키스토어 (2026-09-20)
alias: upload
SHA-1: C6:5A:7E:EA:D7:87:C3:84:B8:B2:5E:E5:D4:DB:2F:F0:C1:B7:C5:D1
비밀번호는 Cursor 채팅에 있습니다. 이 ZIP에는 넣지 않았습니다.
Play Console에는 PEM만 올리세요. JKS는 로컬/USB에만 보관하세요.
